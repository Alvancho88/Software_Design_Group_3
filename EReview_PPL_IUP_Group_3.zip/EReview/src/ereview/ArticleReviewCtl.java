package ereview;
import java.util.*;

public class ArticleReviewCtl {
	
    /**
     * Default constructor
     */
    public ArticleReviewCtl() {
    }
	

}
