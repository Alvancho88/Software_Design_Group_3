package ereview;

public class DialogBox {
	
    /**
     * Default constructor
     */
    public DialogBox() {
    }
}
