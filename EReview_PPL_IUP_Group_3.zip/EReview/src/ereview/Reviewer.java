package ereview;

public class Reviewer {
	String name;
	String email;
	String password;
}
