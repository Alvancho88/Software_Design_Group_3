package ereview;

public class Editor {
	
    /**
     * Default constructor
     */
    public Editor() {
    }
    
	private String name;
	private String email;
	private String password;
}
