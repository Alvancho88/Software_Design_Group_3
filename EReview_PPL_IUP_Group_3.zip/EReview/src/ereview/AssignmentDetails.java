package ereview;

import java.util.ArrayList;

public class AssignmentDetails {
	String judul;
	String abstrak;
	String keyword;
	String subjectarea;
	String category;
	String file;
	String paketharga;
	String totalkata;
	String proofofpayment;
	String reviewer;
	String reviewedarticlefile;
	String orderstatus;
	String rating;
}
