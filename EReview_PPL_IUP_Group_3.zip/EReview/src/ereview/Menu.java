package ereview;

public class Menu {
    /**
     * Default constructor
     */
    public Menu() {
    }
}
