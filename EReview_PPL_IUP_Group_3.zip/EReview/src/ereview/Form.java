package ereview;

public class Form {

    /**
     * Default constructor
     */
    public Form() {
    }
}
