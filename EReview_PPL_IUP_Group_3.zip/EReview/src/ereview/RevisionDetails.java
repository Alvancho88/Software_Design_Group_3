package ereview;

public class RevisionDetails {

    /**
     * Default constructor
     */
    public RevisionDetails() {
    }
}
