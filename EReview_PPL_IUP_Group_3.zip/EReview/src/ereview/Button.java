package ereview;

public class Button {

    /**
     * Default constructor
     */
    public Button() {
    }
}
