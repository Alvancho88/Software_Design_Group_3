package ereview;

public class Page {

    /**
     * Default constructor
     */
    public Page() {
    }
}
