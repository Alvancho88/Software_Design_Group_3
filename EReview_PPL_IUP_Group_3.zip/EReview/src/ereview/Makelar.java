package ereview;

public class Makelar {
	
    /**
     * Default constructor
     */
    public Makelar() {
    }
    
	private String name;
	private String email;
	private String password;
}
