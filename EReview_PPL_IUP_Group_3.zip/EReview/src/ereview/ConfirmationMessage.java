package ereview;

public class ConfirmationMessage {
    /**
     * Default constructor
     */
    public ConfirmationMessage() {
    }
}
