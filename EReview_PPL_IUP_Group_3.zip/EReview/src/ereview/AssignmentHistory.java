package ereview;

public class AssignmentHistory {
    /**
     * Default constructor
     */
    public AssignmentHistory() {
    }

    /**
     * 
     */
    private int assignmentid;

    /**
     * 
     */
    public int assignmenthistory;
}
