package ereview;

import java.util.ArrayList;
import java.util.List;

public class Article {

    /**
     * Default constructor
     */
//    public Articles() {
//    	return;
//    }

    /**
     * 
     */
    private char rating;

}
