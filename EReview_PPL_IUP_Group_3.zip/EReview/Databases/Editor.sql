BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Editor" (
	"EmployeeID"	INTEGER UNIQUE,
	"EmployeeName"	TEXT,
	"EmployeeEmail"	TEXT,
	"EmployeePassword"	TEXT,
	PRIMARY KEY("EmployeeID" AUTOINCREMENT)
);
INSERT INTO "Editor" VALUES (1,'Aldi','test@gmail.com','test');
INSERT INTO "Editor" VALUES (2,'Ivan','test2@gmail.com','test');
INSERT INTO "Editor" VALUES (3,'Nicho','test3@gmail.com','test');
COMMIT;
